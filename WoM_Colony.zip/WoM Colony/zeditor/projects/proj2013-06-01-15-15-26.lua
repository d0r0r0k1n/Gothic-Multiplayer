--Generated with ZEditor by Midas
CreateDraw(2400, 4400, ".", "Font_Old_20_White_Hi.TGA", 255, 255, 255)
