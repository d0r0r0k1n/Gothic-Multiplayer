--Generated with ZEditor by Midas
CreateDraw(3947, 3700, ".", "Font_Old_20_White_Hi.TGA", 255, 255, 255)
