--Generated with ZEditor by Midas
CreateDraw(4050, 3000, ".", "Font_Old_20_White_Hi.TGA", 255, 255, 255)
CreateDraw(4100, 3000, "Bimbol", "Font_Old_10_White_Hi.TGA", 255, 255, 255)
