--Generated with ZEditor by Midas
CreateDraw(2500, 4100, ".", "Font_Old_20_White_Hi.TGA", 255, 255, 255)
