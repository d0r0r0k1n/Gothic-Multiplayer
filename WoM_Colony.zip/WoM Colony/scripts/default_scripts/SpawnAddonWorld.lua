
function InitJhakendarNPC()
    local world = "ADDON\\ADDONWORLD.ZEN";
    SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_ENTRANCE_17",world);--59
--SpawnNPC(Stoneguardian_ADANOSTEMPELENTRANCE_02,"ADW_ADANOSTEMPEL_ENTRANCE_18M",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_ENTRANCE_20",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_ENTRANCE_13",world);

SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_05A",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_05B",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_05C",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_05D",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_05E",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_05F",world);

SpawnNPC(GiantRat(),"ADW_ADANOSTEMPEL_TREASUREPITS_07A",world);
SpawnNPC(GiantRat(),"ADW_ADANOSTEMPEL_TREASUREPITS_07B",world);

SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_09A",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_09B",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_09C",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_09D",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_09E",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_TREASUREPITS_09F",world);


SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_RHADEMES_14A",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_RHADEMES_14B",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_RHADEMES_14C",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_RHADEMES_14D",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_RHADEMES_14E",world);
SpawnNPC(Stoneguardian(),"ADW_ADANOSTEMPEL_RHADEMES_14F",world);--87


-------------- Monster ANZAHL(10) WICHTIG f�r Garaz(FIXME_FILLER) ----------------------------152
SpawnNPC(Minecrawler(), "ADW_MINE_MC_04",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_04",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_03",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_03",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_08",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_08",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_07",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_07",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_02",world);
SpawnNPC(Minecrawler(), "ADW_MINE_MC_02",world);

SpawnNPC(Meatbug(), "ADW_MINE_LAGER_08",world);
SpawnNPC(Meatbug(), "ADW_MINE_LAGER_09",world);
SpawnNPC(Meatbug(), "ADW_MINE_LAGER_05",world);
SpawnNPC(Meatbug(), "ADW_MINE_LAGER_SIDE_04",world);

SpawnNPC(Stoneguardian(), "ADW_GRUFT_01",world);
SpawnNPC(Stoneguardian(), "ADW_GRUFT_02",world);
SpawnNPC(Stoneguardian(), "ADW_MINE_TO_GRUFT_05",world);
SpawnNPC(Stoneguardian(), "ADW_MINE_TO_GRUFT_06",world);--172


--202
SpawnNPC(Blattcrawler(), "ADW_CANYON_TELEPORT_PATH_09",world);
SpawnNPC(Blattcrawler(), "ADW_CANYON_TELEPORT_PATH_09",world);
SpawnNPC(Blattcrawler(), "ADW_CANYON_TELEPORT_PATH_09",world);

SpawnNPC(Giant_DesertRat(), "ADW_CANYON_TELEPORT_PATH_03",world);
SpawnNPC(Giant_DesertRat(), "ADW_CANYON_TELEPORT_PATH_03",world);

SpawnNPC(Giant_DesertRat(), "ADW_CANYON_TELEPORT_PATH_04",world);

SpawnNPC(Razor(), "ADW_CANYON_MINE1_01",world);


SpawnNPC(Razor(), "ADW_CANYON_PATH_TO_LIBRARY_07A",world);
SpawnNPC(Razor(), "ADW_CANYON_PATH_TO_LIBRARY_07A",world);


SpawnNPC(Razor(), "ADW_CANYON_PATH_TO_LIBRARY_36",world);
SpawnNPC(Razor(), "ADW_CANYON_PATH_TO_LIBRARY_36",world);


SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_LIBRARY_40",world);
SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_LIBRARY_40",world);

SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_LIBRARY_03",world);

SpawnNPC(Bloodhound(), "ADW_CANYON_PATH_TO_BANDITS_31",world);

SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_BANDITS_52",world);
SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_BANDITS_52",world);

SpawnNPC(Razor(), "ADW_CANYON_PATH_TO_MINE2_04",world);


SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_31A",world);
SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_31A",world);
SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_31A",world);

SpawnNPC(Blattcrawler(), "ADW_CANYON_PATH_TO_BANDITS_55",world);
SpawnNPC(Blattcrawler(), "ADW_CANYON_PATH_TO_BANDITS_55",world);

SpawnNPC(Shadowbeast(), "ADW_CANYON_PATH_TO_BANDITS_06E",world);

SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_16A",world);
SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_16A",world);
SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_16A",world);

SpawnNPC(OrcBiter(), "ADW_CANYON_PATH_TO_LIBRARY_17",world);

SpawnNPC(OrcBiter(), "ADW_CANYON_ORCS_09",world);


SpawnNPC(Wolf(), "ADW_CANYON_PATH_TO_LIBRARY_37",world);
SpawnNPC(Wolf(), "ADW_CANYON_PATH_TO_LIBRARY_37",world);
SpawnNPC(Wolf(), "ADW_CANYON_PATH_TO_LIBRARY_12A",world);
SpawnNPC(Wolf(), "ADW_CANYON_PATH_TO_LIBRARY_12A",world);
SpawnNPC(Wolf(), "ADW_CANYON_PATH_TO_LIBRARY_12A",world);
SpawnNPC(Wolf(), "ADW_CANYON_PATH_TO_LIBRARY_12A",world);

SpawnNPC(OrcWarrior(), "ADW_CANYON_ORCS_08",world);
SpawnNPC(OrcWarrior(), "ADW_CANYON_ORCS_08",world);

SpawnNPC(OrcWarrior(), "ADW_CANYON_PATH_TO_LIBRARY_14",world);
SpawnNPC(OrcWarrior(), "ADW_CANYON_PATH_TO_LIBRARY_14",world);

SpawnNPC(OrcWarrior(), "ADW_CANYON_PATH_TO_LIBRARY_19",world);
SpawnNPC(OrcWarrior(), "ADW_CANYON_PATH_TO_LIBRARY_20",world);
SpawnNPC(OrcWarrior(), "ADW_CANYON_PATH_TO_LIBRARY_20",world);

SpawnNPC(OrcWarrior(), "ADW_CANYON_ORCS_04",world);

SpawnNPC(OrcWarrior(), "ADW_CANYON_ORCS_05",world);
SpawnNPC(OrcWarrior(), "ADW_CANYON_ORCS_05",world);

SpawnNPC(OrcWarrior(), "ADW_CANYON_ORCS_02",world);
SpawnNPC(OrcShaman(), "ADW_CANYON_ORCS_02",world);
SpawnNPC(OrcShaman(), "ADW_CANYON_ORCS_02",world);

SpawnNPC(Bloodhound(), "ADW_CANYON_PATH_TO_MINE2_09",world);
SpawnNPC(Bloodhound(), "ADW_CANYON_PATH_TO_MINE2_09",world);

SpawnNPC(Bloodhound(), "ADW_CANYON_PATH_TO_MINE2_06",world);


SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_BANDITS_26",world);
SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_BANDITS_26",world);

SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_BANDITS_24",world);

SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_BANDITS_66",world);
SpawnNPC(Giant_DesertRat(), "ADW_CANYON_PATH_TO_BANDITS_66",world);

SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_22",world);
SpawnNPC(MinecrawlerWarrior(), "ADW_CANYON_PATH_TO_BANDITS_22",world);

SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_21",world);

SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_17",world);
SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_17",world);

SpawnNPC(MinecrawlerWarrior(), "ADW_CANYON_PATH_TO_BANDITS_14",world);
SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_14",world);

SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_62",world);
SpawnNPC(Minecrawler(), "ADW_CANYON_PATH_TO_BANDITS_19",world);

SpawnNPC(Blattcrawler(), "ADW_CANYON_PATH_TO_BANDITS_06",world);

SpawnNPC(Blattcrawler(), "ADW_CANYON_PATH_TO_BANDITS_09",world);

--H�hle 


--hintere Mine

------------------------Library----------------------------
SpawnNPC(Shadowbeast(), "ADW_CANYON_LIBRARY_04",world);
SpawnNPC(Shadowbeast(), "ADW_CANYON_LIBRARY_LEFT_08",world);
SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_LEFT_07",world);
SpawnNPC(Shadowbeast(), "ADW_CANYON_LIBRARY_RIGHT_07",world);
SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_RIGHT_13",world);

SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_STONIE_01",world);
SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_STONIE_02",world);
SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_STONIE_03",world);
SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_STONIE_04",world);
SpawnNPC(Stoneguardian(), "ADW_CANYON_LIBRARY_STONIE_05",world);

SpawnNPC(MinecrawlerWarrior(), "ADW_CANYON_MINE1_13",world);
SpawnNPC(MinecrawlerWarrior(), "ADW_CANYON_MINE2_09",world);
SpawnNPC(MinecrawlerWarrior(), "ADW_CANYON_MINE2_09",world);

SpawnNPC(Minecrawler(), "ADW_CANYON_MINE1_10",world);
SpawnNPC(Minecrawler(), "ADW_CANYON_MINE1_05",world);
--337

--369
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_PLATEAU_08",world);


SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_05",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_05",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_05",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_02B",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_02B",world);


SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_11",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_11",world);
--SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_VALLEY_02A",world); --RAUS wegen AlliJack

SpawnNPC(Waran(),"ADW_ENTRANCE_2_VALLEY_08",world);

SpawnNPC(Waran(),"ADW_ENTRANCE_PATH2BANDITS_05P",world);
SpawnNPC(Waran(),"ADW_ENTRANCE_PATH2BANDITS_05P",world);
 

SpawnNPC(Bloodfly(),"ADW_ENTRANCE_PATH2BANDITS_10",world);
SpawnNPC(Bloodfly(),"ADW_ENTRANCE_PATH2BANDITS_10",world);

SpawnNPC(Bloodfly(),"ADW_ENTRANCE_PATH2BANDITS_03",world);

SpawnNPC(Waran(),"ADW_ENTRANCE_PATH2BANDITS_05",world);

SpawnNPC(Razor(),"ADW_ENTRANCE_RUIN1_01",world);
SpawnNPC(GiantRat(),"ADW_ENTRANCE_RUIN1_01",world);


SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_BEHINDAKROPOLIS_04",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_BEHINDAKROPOLIS_04",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_PIRATECAMP_13",world);
SpawnNPC(Blattcrawler(),"ADW_ENTRANCE_2_PIRATECAMP_13",world);

SpawnNPC(Stoneguardian(),"ADW_PORTALTEMPEL_08A",world);
SpawnNPC(Stoneguardian(),"ADW_PORTALTEMPEL_08B",world);

SpawnNPC(Molerat(),"ADW_ENTRANCE_PATH2BANDITSCAVE1_05",world);
SpawnNPC(Molerat(),"ADW_ENTRANCE_PATH2BANDITSCAVE1_06",world);
SpawnNPC(Molerat(),"ADW_ENTRANCE_2_PIRATECAMP_05",world);
SpawnNPC(Molerat(),"ADW_ENTRANCE_2_PIRATECAMP_05",world);

SpawnNPC(Gobbo_Warrior(),"ADW_ENTRANCE_2_PIRATECAMP_19",world);
SpawnNPC(Gobbo_Black(),"ADW_ENTRANCE_2_PIRATECAMP_19",world);
SpawnNPC(Gobbo_Black(),"ADW_ENTRANCE_2_PIRATECAMP_19",world);

SpawnNPC(Shadowbeast(),"ADW_ENTRANCE_2_PIRATECAMP_22",world);
--417


-------------------Ravens Tempel ---------------------- 579
SpawnNPC(Zombie_Addon_Knecht(),"BL_RAVEN_SIDE_17",world);
SpawnNPC(Zombie_Addon_Knecht(),"BL_RAVEN_SIDE_18",world);
SpawnNPC(Zombie_Addon_Knecht(),"BL_RAVEN_SIDE_19",world);
SpawnNPC(Zombie_Addon_Knecht(),"BL_RAVEN_SIDE_20",world);
SpawnNPC(Zombie_Addon_Knecht(),"BL_RAVEN_SIDE_21",world);
SpawnNPC(Zombie_Addon_Knecht(),"BL_RAVEN_SIDE_22",world);--585


-------------------MONSTER------------------------------------ 588
SpawnNPC(SwampGolem(),"ADW_PATH_TO_GOLEM_05",world);
SpawnNPC(SwampGolem(),"ADW_PATH_TO_GOLEM_06",world);
SpawnNPC(SwampGolem(),"ADW_PATH_TO_GOLEM_08",world);

SpawnNPC(SwampGolem(),"ADW_SWAMP_GOLEM_02",world);
SpawnNPC(SwampGolem(),"ADW_SWAMP_GOLEM_03",world);
SpawnNPC(SwampGolem(),"ADW_SWAMP_GOLEM_04",world);

--Bloodflies rechts vom Eingang BL
SpawnNPC(Bloodfly(),"ADW_BL_FLIES_03",world);
SpawnNPC(Bloodfly(),"ADW_BL_FLIES_04",world);
SpawnNPC(Bloodfly(),"ADW_BL_FLIES_06",world);
SpawnNPC(Bloodfly(),"ADW_BL_FLIES_07",world);

--Steg
SpawnNPC(Gobbo_Black(),"ADW_BANDIT_VP1_05",world);


--Sharks hinter Vorposten 3
SpawnNPC(Swampshark(),"ADW_SHARK_01",world);
SpawnNPC(Swampshark(),"ADW_SHARK_02",world);
SpawnNPC(Swampshark(),"ADW_SHARK_03",world);
--und Weg zur�ck zum Damm
SpawnNPC(Swampshark(),"ADW_SHARK_04",world);
SpawnNPC(Swampshark(),"ADW_SHARK_05",world);
SpawnNPC(Swampshark(),"ADW_SHARK_06",world);
SpawnNPC(Swampshark(),"ADW_SHARK_07",world);
SpawnNPC(Swampshark(),"ADW_SHARK_08",world);
SpawnNPC(Swampshark(),"ADW_SHARK_09",world);
SpawnNPC(Swampshark(),"ADW_SHARK_10",world);


--Swamp Shark Stra�e
SpawnNPC(SwampGolem(),"ADW_SWAMP_WAND_01",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_WAND_02",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_WAND_03",world);

SpawnNPC(Swampshark(),"ADW_SWAMP_SHARKSTREET_02",world);
SpawnNPC(Swampshark(),"ADW_SWAMP_SHARKSTREET_03",world);
SpawnNPC(Swampshark(),"ADW_SWAMP_SHARKSTREET_07",world);
SpawnNPC(Swampshark(),"ADW_SWAMP_SHARKSTREET_08",world);
SpawnNPC(Swampshark(),"ADW_SWAMP_SHARKSTREET_09",world);
SpawnNPC(Swampshark(),"ADW_SWAMP_SHARKSTREET_10",world);

SpawnNPC(Swamprat(),"ADW_CANYON_PATH_TO_BANDITS_01B",world);

SpawnNPC(Bloodfly(),"ADW_LITTLE_HILL_03",world);
SpawnNPC(Bloodfly(),"ADW_LITTLE_HILL_03",world);
SpawnNPC(Bloodfly(),"ADW_LITTLE_HILL_04",world);

--Weg rauf zum Big Sea
SpawnNPC(Bloodfly(),"ADW_SWAMP_04",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_04",world);

SpawnNPC(Bloodfly(),"ADW_SWAMP_05",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_05",world);

--Little Sea 

SpawnNPC(Bloodfly(),"ADW_SWAMP_LITTLE_SEA_01",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_LITTLE_SEA_01",world);

SpawnNPC(Bloodfly(),"ADW_SWAMP_LITTLE_SEA_02",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_LITTLE_SEA_02",world);

SpawnNPC(Bloodfly(),"ADW_SWAMP_LITTLE_SEA_03",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_LITTLE_SEA_03",world);

SpawnNPC(Bloodfly(),"ADW_SWAMP_12",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_13",world);

--Pfuetze 
SpawnNPC(Swamprat(),"ADW_PFUETZE_01",world);
SpawnNPC(Swamprat(),"ADW_PFUETZE_02",world);
SpawnNPC(Swamprat(),"ADW_PFUETZE_03",world);
SpawnNPC(Swamprat(),"ADW_PFUETZE_04",world);

--Ruine
SpawnNPC(Gobbo_Warrior(),"ADW_BANDIT_VP1_07_D",world);
SpawnNPC(Gobbo_Black(),"ADW_BANDIT_VP1_07_E",world);
SpawnNPC(Gobbo_Black(),"ADW_BANDIT_VP1_07_F",world);
SpawnNPC(Gobbo_Black(),"ADW_SWAMP_LITTLE_SEA_03_B",world);
SpawnNPC(Gobbo_Black(),"ADW_SWAMP_09_C",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HOHLWEG_01",world);


SpawnNPC(Swamprat(),"ADW_SWAMP_LOCH_01",world);
SpawnNPC(Waran(),"ADW_SWAMP_LOCH_02",world);
SpawnNPC(Waran(),"ADW_SWAMP_LOCH_03",world);
SpawnNPC(Swamprat(),"ADW_SWAMP_LOCH_04",world);

SpawnNPC(Gobbo_Black(),"ADW_SWAMP_08_D",world);
SpawnNPC(Gobbo_Black(),"ADW_SWAMP_08_E",world);

SpawnNPC(Bloodfly(),"ADW_PATH_TO_BL_09",world);
SpawnNPC(SwampDrone(),"ADW_PATH_TO_BL_10",world);
SpawnNPC(Bloodfly(),"ADW_PATH_TO_BL_10",world);
SpawnNPC(Bloodfly(),"ADW_PATH_TO_LOCH_01",world);
SpawnNPC(Bloodfly(),"ADW_PATH_TO_LOCH_01",world);

SpawnNPC(SwampDrone(),"ADW_SWAMP_HILLS_DOWN_05",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_10",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_13",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_14",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_06",world);
SpawnNPC(Bloodfly(),"ADW_SWAMP_05",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_12",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_BF_NEST_06",world);

SpawnNPC(SwampDrone(),"ADW_SWAMP_HOHLWEG_03",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HOHLWEG_04",world);

------------------Senat---(und Wege dorthin)--------------------

--Monster
SpawnNPC(Stoneguardian(),"ADW_SENAT_SIDE_01",world);
SpawnNPC(Stoneguardian(),"ADW_SENAT_SIDE_02",world);
SpawnNPC(Stoneguardian(),"ADW_SENAT_SIDE_03",world);


SpawnNPC(Stoneguardian(),"ADW_SENAT_GUARDIAN_01",world);
SpawnNPC(Stoneguardian(),"ADW_SENAT_GUARDIAN_02",world);
SpawnNPC(Stoneguardian(),"ADW_SENAT_GUARDIAN_03",world);

SpawnNPC(Stoneguardian(),"ADW_SENAT_INSIDE_01",world);

SpawnNPC(Waran(),"ADW_SENAT_MONSTER_01",world);
SpawnNPC(Waran(),"ADW_SENAT_MONSTER_02",world);
SpawnNPC(Waran(),"ADW_SENAT_MONSTER_03",world);
SpawnNPC(Waran(),"ADW_SENAT_MONSTER_04",world);

SpawnNPC(Waran(),"ADW_SENAT_05",world);
SpawnNPC(Waran(),"ADW_SENAT_05",world);

SpawnNPC(Swamprat(),"ADW_SWAMP_HILLS_DOWN_07",world);
SpawnNPC(Swamprat(),"ADW_SWAMP_HILLS_DOWN_07",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HILLS_DOWN_05",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HILLS_DOWN_06",world);


SpawnNPC(SwampDrone(),"ADW_SWAMP_HILLS_DOWN_03",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HILLS_DOWN_03",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_15",world);
SpawnNPC(Swamprat(),"ADW_HOHLWEG_CENTER",world);
SpawnNPC(Swamprat(),"FP_ROAM_BF_NEST_26",world);
SpawnNPC(Swamprat(),"ADW_BANDITSCAMP_RAKEPLACE_03",world);
SpawnNPC(SwampDrone(),"ADW_CANYON_PATH_TO_BANDITS_02",world);
SpawnNPC(SwampDrone(),"ADW_PFUETZE_02",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_LOCH_05",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_LOCH_06",world);


SpawnNPC(Swamprat(),"ADW_SWAMP_TO_BIGSEA_01",world);
SpawnNPC(Swamprat(),"ADW_SWAMP_TO_BIGSEA_01",world);

SpawnNPC(Swamprat(),"ADW_SWAMP_HOHLWEG_02",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HOHLWEG_05",world);
SpawnNPC(SwampDrone(),"ADW_SWAMP_HOHLWEG_05",world);

SpawnNPC(Swamprat(),"ADW_SWAMP_07",world);
SpawnNPC(Swamprat(),"ADW_SWAMP_07",world);--755


-- --------- Monster -----------------------------821
SpawnNPC(Lurker(),"ADW_PIRATECAMP_ISLE1_01",world);
SpawnNPC(Lurker(),"ADW_PIRATECAMP_ISLE1_01",world);
SpawnNPC(Lurker(),"ADW_PIRATECAMP_ISLE1_01",world);

-- -------- Strandlurker ------------------------
SpawnNPC(Waran(),"ADW_PIRATECAMP_BEACH_27",world);
SpawnNPC(Waran(),"ADW_PIRATECAMP_BEACH_27",world);

SpawnNPC(Waran(),"ADW_PIRATECAMP_BEACH_28",world);
SpawnNPC(Waran(),"ADW_PIRATECAMP_BEACH_28",world);
SpawnNPC(Waran(),"ADW_PIRATECAMP_BEACH_28",world);

SpawnNPC(Shadowbeast(),"ADW_PIRATECAMP_CAVE3_04",world);

---------- Einsamer Strand -----------------------

SpawnNPC(Waran(),"ADW_PIRATECAMP_LONEBEACH_11",world);
SpawnNPC(Waran(),"ADW_PIRATECAMP_LONEBEACH_12",world);
SpawnNPC(Firewaran(),"ADW_PIRATECAMP_LONEBEACH_10",world);
SpawnNPC(Firewaran(),"ADW_PIRATECAMP_LONEBEACH_10",world);
SpawnNPC(Firewaran(),"DAW_PIRTECAMP_LONEBEACH_07",world);
SpawnNPC(Firewaran(),"ADW_PIRATECAMP_LONEBEACH_08",world);
SpawnNPC(Waran(),"ADW_PIRATECAMP_LONEBEACH_05",world);
SpawnNPC(Waran(),"ADW_PIRATECAMP_LONEBEACH_04",world);

SpawnNPC(Zombie1(),"ADW_PIRATECAMP_LONEBEACH_CAVE_03",world);
SpawnNPC(MayaZombie2(),"ADW_PIRATECAMP_LONEBEACH_CAVE_03",world);
SpawnNPC(Zombie3(),"ADW_PIRATECAMP_LONEBEACH_CAVE_03",world);

-- --------- Versteckte H�hle ----------------------
SpawnNPC(Lurker(),"ADW_PIRATECAMP_SECRETCAVE_01",world);
SpawnNPC(Lurker(),"ADW_PIRATECAMP_SECRETCAVE_01",world);

------------ Holzf�llerlager -----------------------

SpawnNPC(Meatbug(),"ADW_PIRATECAMP_LUMBER_01",world);
SpawnNPC(Meatbug(),"ADW_PIRATECAMP_LUMBER_01",world);
SpawnNPC(Meatbug(),"ADW_PIRATECAMP_LUMBER_01",world);

-- --------- Vor dem Turm ------------------------

SpawnNPC(Gobbo_Black(),"ADW_PIRATECAMP_PLAIN_01",world);
SpawnNPC(Gobbo_Black(),"ADW_PIRATECAMP_PLAIN_01",world);
SpawnNPC(Gobbo_Black(),"ADW_PIRATECAMP_PLAIN_02",world);

-- --------- Hinter dem Turm --------------------

SpawnNPC(Blattcrawler(),"ADW_PIRATCAMP_PLAIN_05",world);
SpawnNPC(Blattcrawler(),"ADW_PIRATCAMP_PLAIN_05",world);

------------ Wasserloch -------------------------
 
SpawnNPC(Blattcrawler(),"ADW_PIRATCAMP_PLAIN_05",world);
SpawnNPC(Blattcrawler(),"ADW_PIRATCAMP_PLAIN_05",world);

SpawnNPC(Waran(),"ADW_PIRATECAMP_WATERHOLE_08",world);

SpawnNPC(Lurker(),"ADW_PIRATECAMP_WATERHOLE_04",world);

------------ Weg ---------------------------------

SpawnNPC(Blattcrawler(),"ADW_PIRATECAMP_WAY_SPAWN_01",world);
SpawnNPC(Blattcrawler(),"ADW_PIRATECAMP_WAY_SPAWN_02",world);--884



--977
-- ------ Troll ------
SpawnNPC(Troll(),"ADW_VALLEY_BIGCAVE_07",world);
SpawnNPC(Troll(),"ADW_VALLEY_PATH_048_B",world);

-- ------ Gobbo_Black ------
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_PATH_003_A",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_BIGCAVE_08",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_BIGCAVE_08",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_BIGCAVE_08",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_BIGCAVE_08",world);
SpawnNPC(MayaZombie3(),"ADW_VALLEY_BIGCAVE_18",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_PATH_012",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_115_F",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_115_F",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_054_B",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_PATH_054_B",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_PATH_054_D",world);
SpawnNPC(Gobbo_Black(),"ADW_VALLEY_PATH_054_E",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_054_F",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_058_CAVE_09",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_058_CAVE_09",world);
SpawnNPC(Gobbo_Warrior(),"ADW_VALLEY_PATH_058_CAVE_09",world);

-- ------ Harpie ------
SpawnNPC(Harpie(),"ADW_VALLEY_BIGCAVE_06",world);
SpawnNPC(Harpie(),"ADW_VALLEY_BIGCAVE_06",world);
SpawnNPC(Harpie(),"ADW_VALLEY_BIGCAVE_15",world);
SpawnNPC(Harpie(),"ADW_VALLEY_BIGCAVE_15",world);
SpawnNPC(Harpie(),"ADW_VALLEY_BIGCAVE_15",world);
SpawnNPC(Harpie(),"ADW_VALLEY_PATH_110",world);
SpawnNPC(Harpie(),"ADW_VALLEY_PATH_110",world);

-- ------ Snapper ------
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_020",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_020",world);
SpawnNPC(Snapper(),"ADW_VALLEY_BIGCAVE_01",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_048_A",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_048_A",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_048_A",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_047_D",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_047_D",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_047_D",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_047_G",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_047_G",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_038_E",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_038_E",world);
SpawnNPC(Snapper(),"ADW_VALLEY_PATH_038_J",world);

-- ------ Shadowbeast ------
SpawnNPC(Shadowbeast(),"ADW_VALLEY_PATH_029",world);

-- ------ Skeleton ------
SpawnNPC(Skeleton(),"ADW_VALLEY_PATH_020_CAVE_05",world);
SpawnNPC(Skeleton(),"ADW_VALLEY_PATH_020_CAVE_05",world);

-- ------Scavenger ------
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_032_G",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_032_G",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_032_G",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_121_A",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_121_A",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_121_A",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_120_A",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_120_A",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_120_A",world);

-- ------ Molerat ------
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_027",world);
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_045",world);
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_129_B",world);
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_129_B",world);
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_129_B",world);

-- ------ Minecrawler ------
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_131",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_131",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_132_A",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_132_A",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_134",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_134",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_135",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_135",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_135",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_135",world);
SpawnNPC(Minecrawler(),"ADW_VALLEY_PATH_135",world);
SpawnNPC(MinecrawlerWarrior(),"ADW_VALLEY_PATH_058_CAVE_13",world);

-- ------ Blattcrawler ------
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_024_A",world);
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_024_A",world);
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_125",world);
SpawnNPC(SwampGolem(),"ADW_VALLEY_PATH_064_A",world);
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_062",world);
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_062",world);

-- ------ Bloodfly ------
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_102_A",world);
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_102_A",world);
SpawnNPC(ScavengerDemon(),"ADW_VALLEY_PATH_116_A",world);
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_043",world);
SpawnNPC(Swamprat(),"ADW_VALLEY_PATH_043",world);
SpawnNPC(Blattcrawler(),"ADW_VALLEY_PATH_053",world);
SpawnNPC(Bloodfly(),"ADW_VALLEY_PATH_017",world);

-- ------ Meatbug ------
SpawnNPC(Meatbug(),"ADW_VALLEY_PATH_058",world);

-- ------ Orcs ------
SpawnNPC(OrcWarrior(),"ADW_VALLEY_PATH_033_A",world);
SpawnNPC(OrcWarrior(),"ADW_VALLEY_PATH_035",world);
SpawnNPC(OrcWarrior(),"ADW_VALLEY_PATH_036",world);
SpawnNPC(OrcShaman(),"ADW_VALLEY_PATH_115_E",world);

-- ------ Zombie ------
SpawnNPC(MayaZombie1(),"ADW_VALLEY_PATH_072",world);
SpawnNPC(Zombie4(),"ADW_VALLEY_PATH_072",world);
SpawnNPC(Zombie3(),"ADW_VALLEY_PATH_073",world);
SpawnNPC(MayaZombie4(),"ADW_VALLEY_PATH_072",world);
SpawnNPC(Zombie4(),"ADW_VALLEY_PATH_073",world);
SpawnNPC(Zombie2(),"ADW_VALLEY_PATH_073",world);


SpawnNPC(Stoneguardian(),"ADW_VALLEY_SHOWCASE1_02",world);
SpawnNPC(Stoneguardian(),"ADW_VALLEY_SHOWCASE1_03",world);--1100





end