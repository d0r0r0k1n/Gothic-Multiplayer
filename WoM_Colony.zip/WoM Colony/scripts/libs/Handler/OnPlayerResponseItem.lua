function AI_OnPlayerResponseItem(playerid, slot, item_instance, amount, equipped)
	TRADING_OnPlayerResponseItem(playerid, slot, item_instance, amount, equipped);
end
